本包基线：4596（+1 dB）、60秒；每档训练4段、验证2段，算法recal-algorithm-2026-11-02.1。

保护后短按 BTN2 可免标定恢复（上限 3 次/场景），ready后再按BTN1；其他失败仍须CAL。

所有非prepare阶段白名单为[0,4596]，prepare保留历史档位并加入4596；标定开环0增益，维护1631/3秒。

以product-config.json、[BTN2约定](INTERFACE.md)及[操作单](OPERATIONS.md)为本包准据；其他版本说明保留历史适用范围。
