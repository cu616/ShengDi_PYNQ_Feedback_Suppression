"""Feasibility of band-limiting the forward path to the speech band.

Loop gain at frequency f is (forward path gain at f) * H(f) for bypass, and
* (H(f) - Hhat(f)) for cancellation. If the forward path is band-limited, the loop has no
gain outside the band, so the 8.4 kHz resonance cannot support an oscillation. This computes
the maximum stable gain with and without such a filter, using the measured on-site H and the
deployed model.
"""
import json
from pathlib import Path

import numpy as np

FS = 48828.125
CAL = Path(r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\cd514')
MODEL = Path(r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\tail_review_v3'
             r'\models\room_v1\candidate_512.json')

refs, mics = [], []
for path in sorted(CAL.glob('seg_*.npz')):
    with np.load(path) as data:
        refs.append(np.asarray(data['reference'], dtype=float))
        mics.append(np.asarray(data['microphone'], dtype=float))
ref, mic = np.concatenate(refs), np.concatenate(mics)

n = 8192
win = np.hanning(n)
Suu = np.zeros(n // 2 + 1, dtype=np.complex128)
Sum = np.zeros(n // 2 + 1, dtype=np.complex128)
Smm = np.zeros(n // 2 + 1, dtype=np.complex128)
for s in range(0, len(mic) - n, n // 2):
    A = np.fft.rfft(ref[s:s + n] * win)
    B = np.fft.rfft(mic[s:s + n] * win)
    Suu += np.conj(A) * A
    Sum += np.conj(A) * B
    Smm += np.conj(B) * B
H = Sum / np.maximum(Suu, 1e-30)
coh = np.abs(Sum) ** 2 / np.maximum(Suu.real * Smm.real, 1e-30)
freq = np.fft.rfftfreq(n, 1 / FS)
omega = 2 * np.pi * freq / FS

model = json.loads(MODEL.read_text(encoding='utf-8'))
q = np.asarray(model['coefficients'], dtype=float)
lag = int(model.get('lag_first', 1))
Hhat = np.fft.rfft(q, n) * np.exp(-1j * omega * lag)

good = coh > 0.7
db = lambda x: 20 * np.log10(np.maximum(np.abs(x), 1e-30))


def butter_mag(freq, lo, hi, order=4):
    """Magnitude of a band-pass Butterworth response (ideal enough for a feasibility bound)."""
    mag = np.ones_like(freq, dtype=float)
    if lo:
        mag *= 1.0 / np.sqrt(1.0 + (lo / np.maximum(freq, 1e-9)) ** (2 * order))
    if hi:
        mag *= 1.0 / np.sqrt(1.0 + (freq / hi) ** (2 * order))
    return mag


def report(label, F):
    for name, err in (('bypass', H), ('cancel', H - Hhat)):
        loop = F * err
        sel = good
        worst = int(np.argmax(db(loop)[sel]))
        f_worst = freq[sel][worst]
        gmax = -db(loop)[sel][worst]
        print('  %-22s %-7s max|loop| %+6.2f dB @%6.0f Hz  ->  max stable gain %+6.2f dB'
              % (label, name, db(loop)[sel][worst], f_worst, gmax))


print('measured |H| peak overall: %+.2f dB @ %.0f Hz'
      % (db(H)[good].max(), freq[good][int(np.argmax(db(H)[good]))]))
print()
report('no filter', np.ones_like(freq))
print()
for order in (2, 4, 6):
    F = butter_mag(freq, 300.0, 3400.0, order)
    report('BP 300-3400 (o%d)' % order, F)
    print()

# what the loop looks like per band with the best filter
F = butter_mag(freq, 300.0, 3400.0, 6)
print('band-by-band with a 6th-order 300-3400 band-pass:')
for lo, hi in ((100, 300), (300, 1000), (1000, 2000), (2000, 3400), (3400, 6000), (8200, 8600)):
    sel = (freq >= lo) & (freq <= hi) & good
    if not sel.any():
        continue
    print('  %5d-%5d Hz: max|F*H| %+6.2f dB   max|F*(H-Hhat)| %+7.2f dB'
          % (lo, hi, db(F * H)[sel].max(), db(F * (H - Hhat))[sel].max()))
