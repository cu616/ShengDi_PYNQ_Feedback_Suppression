"""Merge the 20 sideways segments (pos_side + pos_side16), fit on 14, validate on 6."""
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, r'D:\OCadence_Project\Flushbonading_FPGA_Contest\tmp\a-feedback\tmp\ssh-deps')
import numpy as np  # noqa: E402
import paramiko  # noqa: E402

KNOWN = r'D:\OCadence_Project\Flushbonading_FPGA_Contest\tmp\a-feedback\tmp\board-known-hosts'
PACK = Path(r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\for_b_side')
PACK.mkdir(parents=True, exist_ok=True)

client = paramiko.SSHClient()
client.load_host_keys(KNOWN)
client.set_missing_host_key_policy(paramiko.RejectPolicy())
client.connect('192.168.2.99', username='xilinx',
               password=os.environ['SHENGDI_SSH_PASSWORD'],
               look_for_keys=False, allow_agent=False, timeout=10)
sftp = client.open_sftp()
count = 0
for directory in ('pos_side', 'pos_side16'):
    for k in range(10):
        remote = '/home/xilinx/%s/seg_%d.npz' % (directory, k)
        target = PACK / ('%s_seg_%d.npz' % (directory.replace('pos_', ''), k))
        try:
            sftp.get(remote, str(target))
            count += 1
        except IOError:
            pass
sftp.close()
client.close()
print('downloaded', count, 'segments')

sys.path.insert(0, r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\wt-a\board\audio_replay')
import replay_calibration as cal  # noqa: E402

FS = 48828.125
items = []
for path in sorted(PACK.glob('*.npz')):
    if path.name.startswith('model'):
        continue
    with np.load(path) as data:
        items.append((path.name, np.asarray(data['reference'], dtype=float),
                      np.asarray(data['microphone'], dtype=float)))
levels = np.array([20 * np.log10(max(np.std(i[2]), 1e-12)) for i in items])
keep = [i for i, lv in zip(items, levels) if abs(lv - np.median(levels)) <= 3.0]
print('segments kept %d/%d, median %.2f dBFS, spread %.2f'
      % (len(keep), len(items), np.median(levels), levels.max() - levels.min()))


def build(subset, cid):
    return cal.Capture(np.concatenate([i[1] for i in subset]),
                       np.concatenate([i[2] for i in subset]), FS,
                       dict(schema_version=1, capture_id=cid, source='board',
                            forward_path_open=True, alignment='same_i2s_frame',
                            dropped_frames=0, fixture_id='room_v1_20261021', hp_volume=40))


split = int(len(keep) * 0.7)
train = build(keep[:split], 'side-train')
valid = build(keep[split:], 'side-valid')
model = cal.fit_path(train, taps=512, ridge=1e-9)
score = cal.evaluate_path(model, valid, train)
out = PACK / 'model_512_side.json'
cal.export_model(out, model, score)
print('fit reduction_db %.2f (train %d / valid %d)'
      % (score['prediction_reduction_db'], split, len(keep) - split))

env = dict(os.environ)
env['PYTHONUTF8'] = '1'
result = subprocess.run(
    [sys.executable, 'scripts/diagnose_peak_margin.py', '--data-dir', str(PACK),
     '--model', str(out), '--delay-frames', '2'],
    cwd=r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\b_tree',
    capture_output=True, text=True, encoding='utf-8', errors='replace', env=env)
print((result.stdout or '')[:1400])
if result.returncode != 0:
    print('STDERR', (result.stderr or '')[:400])
