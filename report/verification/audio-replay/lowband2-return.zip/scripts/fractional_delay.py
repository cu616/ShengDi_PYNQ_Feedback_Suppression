"""Estimate the fractional ref->mic delay, and see whether sub-sample misalignment explains
the 9131 Hz oscillation that the residual magnitude says cannot happen.
"""
import glob
import json
from pathlib import Path

import numpy as np

FS = 48828.125
PACK = Path(r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\for_b_lowband')
files = sorted(glob.glob(str(PACK / 'seg_*.npz')))

n = 8192
win = np.hanning(n)
Suu = np.zeros(n // 2 + 1, dtype=np.complex128)
Sum = np.zeros(n // 2 + 1, dtype=np.complex128)
Smm = np.zeros(n // 2 + 1, dtype=np.complex128)
for path in files:
    with np.load(path) as data:
        ref = np.asarray(data['reference'], dtype=float)
        mic = np.asarray(data['microphone'], dtype=float)
    for s in range(0, len(mic) - n, n // 2):
        A = np.fft.rfft(ref[s:s + n] * win)
        B = np.fft.rfft(mic[s:s + n] * win)
        Suu += np.conj(A) * A
        Sum += np.conj(A) * B
        Smm += np.conj(B) * B
H = Sum / np.maximum(Suu, 1e-30)
coh = np.abs(Sum) ** 2 / np.maximum(Suu.real * Smm.real, 1e-30)
freq = np.fft.rfftfreq(n, 1 / FS)
omega = 2 * np.pi * freq / FS

# unwrap the phase over a coherent, speech-relevant band and fit the linear slope
for lo, hi in ((300, 1000), (1000, 3400), (3400, 6000), (6000, 12000)):
    sel = (freq >= lo) & (freq <= hi) & (coh > 0.8)
    if sel.sum() < 8:
        print('%5d-%5d Hz: not enough coherent bins' % (lo, hi))
        continue
    phase = np.unwrap(np.angle(H[sel]))
    slope, intercept = np.polyfit(omega[sel], phase, 1)
    delay = -slope
    resid = phase - (slope * omega[sel] + intercept)
    print('%5d-%5d Hz: delay %.3f samples, phase-fit residual rms %.1f deg (bins %d)'
          % (lo, hi, delay, np.degrees(np.sqrt(np.mean(resid ** 2))), int(sel.sum())))

# what a fractional-delay error costs at the observed howl frequency
model = json.loads((PACK / 'model_512_strong.json').read_text(encoding='utf-8'))
lag = int(model.get('lag_first', 1))
k = int(round(9131 * n / FS))
print('\nat 9131 Hz: one sample is %.1f degrees of phase' % (360 * 9131 / FS))
for frac in (0.0, 0.1, 0.2, 0.3, 0.5, 1.0):
    print('  fractional misalignment %.1f sample -> %+6.1f deg at 9131 Hz'
          % (frac, 360 * 9131 / FS * frac))
