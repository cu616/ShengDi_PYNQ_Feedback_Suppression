"""Extend the band table to 12 kHz and look specifically at the 9131 Hz howl.

B's point: my table stopped at 8600 Hz while the board actually howled at 9131 Hz three
times, so the limiting band may never have been measured. This uses the same 16 segments
and the same model as the diagnostic run.
"""
import glob
import json
from pathlib import Path

import numpy as np

FS = 48828.125
PACK = Path(r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\for_b_lowband')
files = sorted(glob.glob(str(PACK / 'seg_*.npz')))
model = json.loads((PACK / 'model_512_strong.json').read_text(encoding='utf-8'))
q = np.asarray(model['coefficients'], dtype=float)
lag = int(model.get('lag_first', 1))

n = 8192
win = np.hanning(n)
Suu = np.zeros(n // 2 + 1, dtype=np.complex128)
Sum = np.zeros(n // 2 + 1, dtype=np.complex128)
Smm = np.zeros(n // 2 + 1, dtype=np.complex128)
for path in files:
    with np.load(path) as data:
        ref = np.asarray(data['reference'], dtype=float)
        mic = np.asarray(data['microphone'], dtype=float)
    for s in range(0, len(mic) - n, n // 2):
        A = np.fft.rfft(ref[s:s + n] * win)
        B = np.fft.rfft(mic[s:s + n] * win)
        Suu += np.conj(A) * A
        Sum += np.conj(A) * B
        Smm += np.conj(B) * B
H = Sum / np.maximum(Suu, 1e-30)
coh = np.abs(Sum) ** 2 / np.maximum(Suu.real * Smm.real, 1e-30)
freq = np.fft.rfftfreq(n, 1 / FS)
omega = 2 * np.pi * freq / FS
Hhat = np.fft.rfft(q, n) * np.exp(-1j * omega * lag)
err = H - Hhat
db = lambda x: 20 * np.log10(np.maximum(np.abs(x), 1e-30))

print('%-14s %6s %8s %8s %8s %8s' % ('band Hz', 'bins', 'max|H|', 'max|E|', '@Hz', 'coh'))
for lo, hi in ((300, 1000), (1000, 2000), (2000, 3400), (3400, 6000), (6000, 8200),
               (8200, 8600), (8600, 10250), (10250, 12000), (300, 12000)):
    sel = (freq >= lo) & (freq <= hi) & (coh > 0.8)
    if not sel.any():
        print('%-14s %6d  (no coherent bin)' % ('%d-%d' % (lo, hi), 0))
        continue
    worst = int(np.argmax(db(err)[sel]))
    print('%-14s %6d %8.2f %8.2f %8.0f %8.2f'
          % ('%d-%d' % (lo, hi), int(sel.sum()), db(H[sel]).max(),
             db(err[sel][worst]), freq[sel][worst], float(np.median(coh[sel]))))

print('\nnear the observed howl at 9131 Hz (coherence > 0.7):')
sel = (freq >= 8800) & (freq <= 9500) & (coh > 0.7)
if sel.any():
    worst = int(np.argmax(db(err)[sel]))
    f_worst = freq[sel][worst]
    print('  worst bin %.0f Hz: |H| %+.2f  |Hhat| %+.2f  |E| %+.2f  coh %.2f'
          % (f_worst, db(H[sel][worst]), db(Hhat[sel][worst]), db(err[sel][worst]),
             coh[sel][worst]))
    k = int(round(9131 * n / FS))
    print('  9131 Hz:          |H| %+.2f  |Hhat| %+.2f  |E| %+.2f  coh %.2f'
          % (db(H[k]), db(Hhat[k]), db(err[k]), coh[k]))
else:
    print('  no coherent bin in 8800-9500 Hz (coherence stays below 0.7)')

print('\nphase of the residual where it matters (|E| largest bins):')
sel = (freq >= 300) & (coh > 0.8)
order = np.argsort(db(err)[sel])[::-1][:6]
idx = np.where(sel)[0][order]
for i in idx:
    loop_phase = np.degrees(np.angle(err[i] * np.exp(-1j * omega[i] * 2)))
    print('  %6.0f Hz: |E| %+.2f dB  residual loop phase (incl. 2 frames) %+7.1f deg'
          % (freq[i], db(err[i]), loop_phase))
