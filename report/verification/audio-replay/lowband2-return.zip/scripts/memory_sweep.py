"""How much memory does the low band actually need?

Sweeps the number of taps (and the decimation factor) to find what residual, and therefore
what usable gain, is reachable. This is the design table B needs before committing to RTL.
"""
import glob
from pathlib import Path

import numpy as np

FS = 48828.125
SEGS = Path(r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\for_b_side\segments')
files = sorted(glob.glob(str(SEGS / 'seg_*.npz')))
db = lambda x: 20 * np.log10(np.maximum(np.abs(x), 1e-30))


def lowpass(x, cutoff_hz, taps=2049):
    n = np.arange(taps) - (taps - 1) / 2
    fc = cutoff_hz / FS
    h = 2 * fc * np.sinc(2 * fc * n) * np.kaiser(taps, 8.0)
    h /= h.sum()
    return np.convolve(x, h, mode='same')


def fit(ref, mic, taps, lag=1):
    n = len(ref) - taps - lag
    if n < 2 * taps:
        return None
    X = np.empty((n, taps))
    for k in range(taps):
        X[:, k] = ref[taps - k: taps - k + n]
    q, *_ = np.linalg.lstsq(X, mic[lag + taps: lag + taps + n], rcond=None)
    return q


def low_band_residual(dec, taps):
    fs2 = FS / dec
    cutoff = fs2 / 2 * 0.85
    tr_r, tr_m, ts_r, ts_m = [], [], [], []
    for i, path in enumerate(files):
        with np.load(path) as d:
            r = lowpass(np.asarray(d['reference'], float), cutoff)[::dec]
            m = lowpass(np.asarray(d['microphone'], float), cutoff)[::dec]
        (tr_r if i < 14 else ts_r).append(r)
        (tr_m if i < 14 else ts_m).append(m)
    q = fit(np.concatenate(tr_r), np.concatenate(tr_m), taps)
    if q is None:
        return None
    r_all, m_all = np.concatenate(ts_r), np.concatenate(ts_m)
    n = min(1024, len(r_all) // 2)
    win = np.hanning(n)
    Suu = np.zeros(n // 2 + 1, dtype=np.complex128)
    Sum = np.zeros(n // 2 + 1, dtype=np.complex128)
    Smm = np.zeros(n // 2 + 1, dtype=np.complex128)
    for s in range(0, len(r_all) - n, n // 2):
        A = np.fft.rfft(r_all[s:s + n] * win)
        B = np.fft.rfft(m_all[s:s + n] * win)
        Suu += np.conj(A) * A
        Sum += np.conj(A) * B
        Smm += np.conj(B) * B
    H = Sum / np.maximum(Suu, 1e-30)
    coh = np.abs(Sum) ** 2 / np.maximum(Suu.real * Smm.real, 1e-30)
    freq = np.fft.rfftfreq(n, 1 / fs2)
    omega = 2 * np.pi * freq / fs2
    k = np.arange(taps)
    Hhat = np.exp(-1j * omega) * (np.exp(-1j * np.outer(omega, k)) @ q)
    err = H - Hhat
    sel = (freq >= 300) & (freq <= 1000) & (coh > 0.8)
    w = int(np.argmax(db(err)[sel]))
    return dict(dec=dec, taps=taps, fs2=fs2, memory_ms=taps / fs2 * 1000,
                max_H=float(db(H[sel]).max()), max_E=float(db(err[sel][w]),
                ), worst_hz=float(freq[sel][w]), threshold=float(-db(err[sel][w])))


print('%-4s %6s %8s %10s %10s %10s' % ('dec', 'taps', 'fs2 Hz', 'memory ms', 'max|E| dB', 'threshold'))
for dec, taps_list in ((8, (384, 768, 1536, 3072)), (16, (384, 768, 1536))):
    for taps in taps_list:
        out = low_band_residual(dec, taps)
        if out is None:
            print('%-4d %6d  insufficient data' % (dec, taps))
            continue
        print('%-4d %6d %8.1f %10.1f %10.2f %10.2f'
              % (out['dec'], out['taps'], out['fs2'], out['memory_ms'], out['max_E'],
                 out['threshold']))
print('\nreference: present 512 taps at full rate -> -8.63 dB at 358 Hz (threshold +8.63)')
print('target: about -18 to -20 dB in 300-1000 Hz to reach a +15..+20 dB usable gain')
