"""Per-band residual of the decimated 384-tap stage, especially at the 337-358 Hz limiter."""
import glob
from pathlib import Path

import numpy as np

FS = 48828.125
DEC = 8
FS2 = FS / DEC
SEGS = Path(r'D:\OCadence_Project\Flushbonading_FPGA_Contest\_a_work\for_b_side\segments')
TAPS = 384


def lowpass(x, cutoff_hz, taps=1025):
    n = np.arange(taps) - (taps - 1) / 2
    fc = cutoff_hz / FS
    h = 2 * fc * np.sinc(2 * fc * n) * np.kaiser(taps, 8.0)
    h /= h.sum()
    return np.convolve(x, h, mode='same')


def fit_fir(ref, mic, taps, lag=1):
    n = len(ref) - taps - lag
    X = np.empty((n, taps))
    for k in range(taps):
        X[:, k] = ref[taps - k: taps - k + n]
    q, *_ = np.linalg.lstsq(X, mic[lag + taps: lag + taps + n], rcond=None)
    return q


def decimate(path):
    with np.load(path) as d:
        r = lowpass(np.asarray(d['reference'], float), FS2 / 2 * 0.85)[::DEC]
        m = lowpass(np.asarray(d['microphone'], float), FS2 / 2 * 0.85)[::DEC]
    return r, m


files = sorted(glob.glob(str(SEGS / 'seg_*.npz')))
train = files[:14]
test = files[14:]

tr_r, tr_m = [], []
for path in train:
    r, m = decimate(path)
    tr_r.append(r)
    tr_m.append(m)
q = fit_fir(np.concatenate(tr_r), np.concatenate(tr_m), TAPS, lag=1)

ts_r, ts_m = [], []
for path in test:
    r, m = decimate(path)
    ts_r.append(r)
    ts_m.append(m)
r_all = np.concatenate(ts_r)
m_all = np.concatenate(ts_m)

n = 1024
win = np.hanning(n)
Suu = np.zeros(n // 2 + 1, dtype=np.complex128)
Sum = np.zeros(n // 2 + 1, dtype=np.complex128)
Smm = np.zeros(n // 2 + 1, dtype=np.complex128)
for s in range(0, len(r_all) - n, n // 2):
    A = np.fft.rfft(r_all[s:s + n] * win)
    B = np.fft.rfft(m_all[s:s + n] * win)
    Suu += np.conj(A) * A
    Sum += np.conj(A) * B
    Smm += np.conj(B) * B
H = Sum / np.maximum(Suu, 1e-30)
coh = np.abs(Sum) ** 2 / np.maximum(Suu.real * Smm.real, 1e-30)
freq = np.fft.rfftfreq(n, 1 / FS2)
omega = 2 * np.pi * freq / FS2
k = np.arange(TAPS)
Hhat = np.exp(-1j * omega * 1) * (np.exp(-1j * np.outer(omega, k)) @ q)
err = H - Hhat
db = lambda x: 20 * np.log10(np.maximum(np.abs(x), 1e-30))

print('%-14s %6s %8s %9s %8s %6s' % ('band Hz', 'bins', 'max|H|', 'max|H-Hhat|', '@Hz', 'coh'))
for lo, hi in ((300, 400), (400, 1000), (1000, 2000), (2000, 2600), (2600, 2950), (300, 2600)):
    sel = (freq >= lo) & (freq <= hi) & (coh > 0.8)
    if not sel.any():
        print('%-14s (no coherent bin)' % ('%d-%d' % (lo, hi)))
        continue
    w = int(np.argmax(db(err)[sel]))
    print('%-14s %6d %8.2f %9.2f %8.0f %6.2f'
          % ('%d-%d' % (lo, hi), int(sel.sum()), db(H[sel]).max(), db(err[sel][w]),
             freq[sel][w], float(np.median(coh[sel]))))

print('\nreference (full-rate 512 taps on the same fixture): necessary +8.63 dB, phase +10.38 dB')
print('interpretation: if 300-2600 Hz reaches about -15 dB the two-stage idea works; the band edge '
      '2600-2950 Hz would stay with the full-rate stage')
