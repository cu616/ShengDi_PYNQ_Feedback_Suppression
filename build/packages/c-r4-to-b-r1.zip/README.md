# r4 → B：汇总判读输入

唯一数据入口：summary-v3.json → fir_switch_pairs（2组）。每项源内响应见summary.json → trials → source_response。
原返回ZIP、汇总和状态保持字节原样；逐文件哈希在handoff-manifest.json，来源A=d013930。
C配置/配对区间/差分算术/寄存器时间线审核通过，详见c-validity-review.json。

现在即可完成Part二的元数据限定判读；原PCM独立复算仍等5个既有NPZ，不因此搁置汇总分析。
列两次repeat的原值和方向，repeat散布只作描述；不以1.5dB门禁或两次散布设通用分辨率。
区分实际全频带测量与只覆盖门控bin的白谱稳态参考，低频方向不一致和高频增大照实列出。
不生成MSG/ASG，不写全程音质或抗啸叫通过；PROXY真人/听众仍未测。

B=71d6a34闭环/余量/控制数值已由C独立通过；N1–N3发布措辞与机器标签仍待修，详见c-b-revision-review.json。
修订在现场结果到达后发生，不追认为事前预测。默认模型和无新候选决定保持。
本包为离线数据交接，无板端执行步骤；真人现场继续使用已发布的c-sprint-rc01-human-r1完整包。
