# 合成WAV管线验证

固定检出：`be3200ecf4a5b1df8901f1111da4685c0f8fedc8`。

真值+3dB；relative_speech_change_db=2.999839153，误差=-0.000160847dB，要求绝对误差<0.5dB。

长度不等、削顶、采样率不同三组均返回failed及明确原因。

全部WAV为合成；未做真人/听众验收，不报绝对SPL。
