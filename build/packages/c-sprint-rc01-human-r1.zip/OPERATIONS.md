## 2026-10-25 集中实验 RC0

维护者C；本节原样进入OPERATIONS.md。当前包 **RC0.1-human-r1 / c-sprint-rc01-1.0.5**，只做真人和固定听众比较。
A=d013930已补交r4原回包，C配置/配对差分/寄存器时间线审核通过；5个非人声原NPZ尚待独立波形复算。
本包不复制历史通过标记，不重复FIR对照或60秒工程项，最新结论以STATE为准。
目的：确认当前工作点是否有真人可辨扩声，以及固定听众位置系统开/关的实际变化；负面结果同样有效，不能靠降增益过关。

### 唯一入口与身份

- C电脑完整ZIP：`D:\Flushbonading_Contest\ShengDi_PYNQ_Feedback_Suppression\build\packages\c-sprint-rc01-human-r1.zip`。
- 板卡全量解压到：`/home/xilinx/jupyter_notebooks/base/audio/c-sprint-rc01-human-r1/`，使用新目录，保留r4原件。
- Notebook绝对路径：`/home/xilinx/jupyter_notebooks/base/audio/c-sprint-rc01-human-r1/sprint.ipynb`。
  重启内核，只运行从上往下**第1个代码格**（全包唯一），首行：
  `# C sprint RC0.1-human-r1: live speech and listener only, -14 dB, v2`。
  不用In[n]定位，不拷代码、不现场换单件。
  A在d013930新增的run_rc4_human.sh把5秒讲话倒计时放在START回调返回前，期间Codec仍静音；
  本次直接使用上述Notebook交互，按START开始后讲话，避免预先讲完。其旧15项包装入口不用于这5项会话。
- 绑定A=`85f4967f242eed61eaa6b74041be931c2f5bc7a0`，五件Python来自根目录，bit/hwh来自其v2目录，逐字节核验。
  bit SHA256=`61bb71aabb824c57191edcea93d1333143cd959c16d43028585913c54a8f61fa`；
  hwh SHA256=`92b499a39d04de891632a89512bfff49f7482a332344128556b1506529d1b75b`；MAX_RUN_FRAMES=3000000。
  A的942fd5b修复在包内，C未改A驱动或RTL。本包虽然带完整v2资产，**不调用连续运行**。
- 默认calibrated_20261024（原strong），512 taps、lag_first=1、Q20；
  文件SHA256=`c8be7f78e7ccb73c8b023aa9e74ddaa0914bc4dabf1e2de91ce46114a0679f9a`；
  Q20 SHA256=`c9d3b1e658fd2ed8b731904eaa1f2bec62677b732f5bebe1acf34f1d96fa2160`。
  固定48828.125Hz、Codec40、−14dB/Q12=817、EQ identity。路径门禁和系统关是gain=0开路，其他项FIR开启。
  candidate_512不作默认或后备；场景变化交B重标定，不在新场景套用旧系数。
- A先读preflight.all_ok并核对版本；缺失/false/版本不符回PREFLIGHT_FAIL，资产不符回ASSET_MISMATCH。
  均不上板、不改包。机器可读预检自动生成；唯一代码格在导入PYNQ前再次核对载荷、模型、资产及预检哈希。

### 发送方自检

`SELFTEST ok | trials=5 | window_frames min=14920 | gate=passed | 预计板端 0.434分钟（另加配置和人工等待）`

可选在解压目录执行`python3 sprint_selftest.py`，静默使用真实Q20及A原件纯参数前缀，不导入PYNQ、不覆盖preflight。
软件夹具的HUMAN/CLEAR确认是合成分支控制，preflight明确标synthetic_human_confirmation，不能算真人或硬件验收。
模型taps/lag_first/Q20和−12/−6/0三点ref/mic映射都在preflight中；旧等源/预算及1帧余量拒绝控制保留。
本包门禁运行1.02秒、定音1秒，源内14920帧；人声/听众每项8秒、1帧静音数字源，保存末尾16384帧。
全程波形未覆盖的区间仍未知，不能把8秒人耳报告和0.336秒PCM混成全程波形证据。

### 一次真人现场会话

1. **先备齐人和测量条件**：A为唯一操板者，安排实际讲话者和听众；确认音响可立即断电，不戴耳机。
   麦克风、音响、前放及位置与strong标定一致。准备同一个固定录制人声源，固定外部播放设备、位置和音量；
   听众/测量设备位置及测量增益固定，关闭AGC。用于定量比较的录音设备必须能确认固定增益且无AGC。
   如果不具备录音条件，可完成真人报告，但听众定量结果仍未测；不能将手机自动增益录音冒充固定增益。
2. **启动唯一代码格**：出现PACKAGE_OK、DEFAULT_MODEL和HUMAN_SESSION_ONLY_5_TRIALS后，输入READY、SAME_SCENE。
   一次写清声源到麦距离、设备/听众位置、固定文件及音量、测量增益和AGC状态。
   确有真人讲话和人耳评价才输入HUMAN_LIVE_AND_LISTENING；PROXY或未核实会在发声前结束本轮，避免无效再跑。
3. **第1项路径门禁**：停止手机和全部外部声源/讲话，配置完成且仍静音后输入START，只播放包内定音。
   既有定音/噪底/漂移门槛保留，失败立即静音停批，不改时长或阈值。
4. **第2项真人8秒**：按提示在START时才讲话，不移动夹具。人耳如实选择CLEAR/DISTORTED/NO_AMPLIFICATION/HOWL/UNKNOWN。
   **只有可辨扩声且清晰才选CLEAR；仅听见原声选NO_AMPLIFICATION。** 不能以低音量不啸叫代替扩声效果。
   三类负面报告记failed并停批；UNKNOWN记未测，不虚填通过。保护、削顶或恢复未知也立即停批。
5. **第3项系统关8秒**：外部设备播放固定录制人声，系统为gain=0开路。固定听众位置记录声音。
   测量录音可用前6秒播放人声、后2秒停源背景；分别导出off-speech.wav和off-noise.wav。
   准备好在同一8秒状态内完成这两段，不把驱动结束后已静音的背景当作运行中的噪声。
6. **第4项门禁与第5项系统开8秒**：先停止外部声源，完成同一门禁；再按START播放完全相同的人声和音量。
   −14dB、FIR开启；位置、模拟配置、测量增益不变。按相同6+2秒方式录出on-speech.wav和on-noise.wav，并如实填人耳报告。
   路径门禁运行漂移5dB及所有保护门槛保持；不因真人或录音困难放宽。异常不继续第二种配置。
7. **录音与听众报告一次填齐**：程序提前打印本轮绝对目录
   `/home/xilinx/jupyter_notebooks/base/audio/c-sprint-rc01-human-r1/results/sprint-<id>/listener/`。
   在确认提示前把四份固定名称WAV拷入：均单声道未压缩PCM16、同采样率、各至少1秒，人声两份同长度且无削顶。
   四份确实同源/同位置/同增益/无AGC才填FIXED_SOURCE_FIXED_GAIN_NO_AGC，否则回车记未测。
   程序做背景功率扣除并要求人声高于背景6dB；结果可为负值，不预设改善，未校准不输出绝对SPL。
   最后一次填写听众位置开/关的可辨扩声、清晰度、底噪、音色和失真；不确定写未知。
   listener passed表示定量测量资格通过，不自动表示扩声收益为正。人耳报告另列human_listener_report。
8. **停止、恢复、回包**：非START取消；保护/削顶/听感异常/门禁失败/通信落盘错误/恢复未知均停止。
   持续尖叫、严重失真或异常发热立即断音响电源并中断。A原驱动执行静音/清理，未知或失败时保持断电并交A处置。
   不自动重试、升档、换旧场系数或在原增益旁路。缺少清理回执记未核实，有明确失败才记failed，均不继续。
   最终RETURN_PACKAGE给唯一结果包：
   `/home/xilinx/jupyter_notebooks/base/audio/c-sprint-rc01-human-r1/results/sprint-<id>/return-results.zip`。
   A只返此ZIP；包含状态、汇总、原音频哈希和板端绝对路径，NPZ/WAV留板，不自动上传人声。
   若内核被强杀，保留现场，在上述解压目录Terminal运行以下完整命令只封存既有记录，不重播：
   `python3 -c "from pathlib import Path; import json; from sprint_experiment import collect; [collect(p.parent,json.loads(p.read_text())) for p in Path('results').glob('sprint-*/summary.json')]"`。

顺利完成仅5项：2门禁、1真人、2听众，纯采集26.04秒；加配置、START、人耳报告及拷录音时间。
fir_comparison/continuous_60s本会话均记not_tested及not scheduled，不借用旧r4填本次通过；历史证据由C另行关联。
EQ identity，均衡贡献未测；不产生MSG/ASG，不以保护、削顶或尖峰直接判啸叫。
另一队友按冻结操作单的独立复现仍是单独验收，不能把A再次执行或C软件自测算作完成。

### r4原件交付要求

不重跑r4。原返回ZIP已从d013930取得，SHA256=9fd5c28704df0b35750cdf85fbd66cfee894db0467bb3ef22af0c9c3cb0a3422。
只需一次附同一轮现有07-fir-off.npz、09-fir-on.npz、11-fir-on.npz、13-fir-off.npz、15-continuous-60s.npz，
用于C独立复算FIR与当前配置60秒尾部算术。无需人声/听众PCM，无需补采；保持原文件字节，按原返回清单核哈希。
将这5个NPZ合成一个r4-review-return.zip提交，明确仓库位置；它与真人会话返回包分别留证，原返回ZIP无需再交。
FIR是4项/2组配对，r4前14项为有界试次；不写“14项FIR配对”。
60秒工程观测仅寄存器时间线+尾PCM约0.559%，不认证全程音质、话筒无削顶或全程无啸叫。
v2实际时序WNS/WHS=0.801/0.015ns，1输入/3输出缺外部延迟约束，不称完整I/O签核。
