# 模型包（B 线交付 C 集成用）

> 本目录只有系数与包装说明，不含音频。系数是 **24 位补码、20 位小数的整数**
> （`coefficients_q20` 原样照抄），与 `docs/contracts/feedback-fir-v1.md` 的加载语义一致：
> `coeff_begin` 空闲时启动，按 `h[0]…h[TAPS−1]` 顺序传输、无地址、加载完成才接受采样。
>
> **实测阈值未验证。** 这里所有数字都是**模型推算**，不是 ASG，也不是"某档一定叫"。

## 1. 清单

| 文件 | 抽头 | 拍数 3N+3 | SHA256（前 16） | 用途 |
|---|---:|---:|---|---|
| `room_v1/baseline_256.json` | 256 | 771 | `aea6dc0645be6677` | 房间夹具基线 |
| `room_v1/candidate_512.json` | 512 | 1539 | `854fb75dbb6c6b46` | 房间夹具候选（B 推荐） |
| `room_v1/baseline_256_padded512.json` | 256→512 | 1539 | `4bae553647e63efd` | 房间基线装进 512 位流用（补零） |
| `box_v1/baseline_256.json` | 256 | 771 | `4f0422c333a45438` | 箱体夹具基线（512 在箱体无收益，不提供候选） |
| `box_v1/baseline_256_padded512.json` | 256→512 | 1539 | `f87aa34f7731a773` | 箱体基线装进 512 位流用（补零） |

**本轮按 C 的夹具安排：A 当前是关盖箱体，先用 `box_v1/`；`room_v1/` 作为独立房间场景
候选保留，不混用夹具、阈值或增益范围。**

完整字段（字节数、`q20_max_abs`、`l1_q20`、量化差异、fixture、hp_volume、status）
在 [`manifest.json`](manifest.json)。取文件用 `git pull` 后直接读本目录，
不要用聊天里贴的路径——各电脑路径不相通。

**清单结构（2026-10-23 23:30 起）**：`manifest.models` 只放**可部署的 3 个模型**，
就是 C 的 `load_registry` 的输入；上表里两件 `*_padded512.json` 属派生件，放在
`manifest.derived_artifacts`，**不参与注册**。原因：补零产物的 `coefficients_sha256`
与原模型的 `padded_512_sha256` 相同，两条记录同时存在会让"按系数反查模型"出现歧义，
整行被判 `model_not_in_approved_registry`。三份模型文件本身未改动。
每条记录新增 `coefficients_sha256`（原数组）与 `padded_512_sha256`（尾部补零到 512 后）两列，
口径与 C 的 `qhash()` 相同（`<i4` little-endian）。

## 2. 系数语义与兼容条件

| 项 | 值 | 说明 |
|---|---|---|
| `lag_first` | 1 | `p[n] = Σ h[k]·u[n−1−k]`；频域必须带 `e^{−j2πf/fs}` |
| Q 格式 | 24 位补码 / 20 位小数 | 范围 ±8388607；本包 `q20_max_abs` 见清单 |
| 抽头容量 | ≤ 681 | `3N+3 ≤ 2048` 拍/帧；512 → 1539，680 → 2043（只剩 5 拍，不建议） |
| 采样率 | 48828.125 Hz | 与 `audio_replay` 一致 |
| 加载失败 | 必须报错并静音 | 半套系数不能继续跑（契约要求检查 `protocol_error`） |
| 加载项数 | **必须恰好等于位流的 TAPS** | `feedback_fir.v` 只在 `load_index==TAPS-1` 时置 `loaded`；512 位流只发 256 项会让 `in_ready` 永远为 0 |
| 256 模型装 512 位流 | **只能补零**，且分开记账 | 见下面「补零约定」；不能用它的名义报告 512 的收益 |

`status` 字段现为 `offline_candidate_not_board_validated`。
**只有 A 在板上做完成对对照，才能改成已验证**；批处理脚本不得把它当作已验证模型。

## 2.1 补零约定（256 模型 → 512 位流）

数学上尾部补零不改变频响（实测 `max|ΔH| = 0.000e+00`），但**协议上必须发满 512 项**。
本目录已直接提供补零产物，避免各方各自实现造成口径分歧：

- `*_padded512.json`：`taps=512`、`loaded_taps=512`、`logical_taps=256`、
  `derived_from_sha256` 指回原模型、`status=derived_padding_not_a_new_model`。
- 记录要求：日志里同时写"原模型 SHA256"和"实际加载系数 SHA256"，并注明 `logical_taps`。
- **禁止**：把补零产物当成新训练的 512 模型；用它去论证 512 相对 256 的收益。
  512 的收益只能用 `room_v1/candidate_512.json`（在 6 段上重新拟合）来论证。

底层加载实现与验证归 A；C 按 A 确认后的约定集成。若 A 选择用 256 位流，则直接加载
`baseline_256.json`，不需要补零产物。

## 3. 数据依据

- 训练：`manifest/` 6 段旁路直采，fixture `room_v1_20261021`，hp_volume 40，
  ref RMS −24.0 dBFS、mic −25.1 dBFS，延迟全 125 帧，16384 帧/段。
- 独立验证：`candidate_room_v1_256_final(1)/` 的 `seg_1/5/6/7`（另一个场次，mic −12.9…−14.6）。
  该批 `seg_0/2` 延迟 124、`seg_3/4/8` 是音响待机，**都不能用**。
- 箱体：`training_box_v1.npz` 拟合、`validation_box_v1.npz` 验证。

## 4. 同条件比较（逐段时域残差，负=更好）

| 模型 | 本场 RMS | 跨场 RMS | 8.2–8.6k 本场 | 8.2–8.6k 跨场 |
|---|---:|---:|---:|---:|
| `room_v1/baseline_256` | −9.87 | −8.85 | −18.2 | −13.8 |
| `room_v1/candidate_512` | **−11.16** | **−10.88** | **−23.3** | −14.6 |

候选成立（每子带不差，本场 8.2–8.6k 好 5.1 dB，跨场 100–300 Hz 好 5.6 dB）。
箱体上候选不成立（256 −9.79 vs 512 −10.17，只差 0.38 dB）。

## 5. 使用方法

```text
1) git pull 后取本目录三个 JSON，按夹具选一个；
2) 用现有加载器读 coefficients_q20（整数原样写入，不要先转浮点再量化）；
3) 确认位流抽头数 ≥ 模型抽头数（512 候选必须配 512 位流，sha256 8b2426f4…）；
4) 记录 gain_q12、hp_volume、位流 sha256、fixture_id，与系数 sha256 一起入表；
5) 恢复基线：换回 baseline_256 + 同一位流即可，不需要重建。
```

## 6. 下一轮的预期与否定条件

- 预期：同场次内 512 的抵消起振点比 256 高 **+2…+5 dB**（模型中心 +7.6 dB，历史只兑现 +4）。
- 尾段 `residual/mic` 在 8.2–8.6 kHz 应读到 **−18…−26 dB**；若只有 −6 dB 以内，
  说明闭环的 `H` 与标定不同，先查电平/对齐，不要再改模型。
- 若 512 的起振点比 256 高出不到 **1.5 dB**，本候选被否定，回基线。

详细依据见
[`report/verification/model-package-2026-10-23/README.md`](../report/verification/model-package-2026-10-23/README.md)。
